function playGame() {
	var startingBetText = document.getElementById("formInput").value;
	console.log(startingBetText);
	var startingBet = Number(startingBetText.slice(1,startingBetText.length));
	var die1 = 0;
	var die2 = 0;
	var numRolls = 0; // number of rolls of dice taken 
	var playerMoney; //the amount the player has at a given round of the game
	var maxMoney; //The max amount of money the player has at a given round
	var indexOfMaxMoney; //The roll in which maxMoney was obtained
	
		
	
	if(startingBet <= 0){
		alert("Your initial bet must be positive. Let's try again.")
		resetForm();
	}
	
	var playerMoney = startingBet;
	maxMoney = playerMoney;
	indexOfMaxMoney = 0;
	 
		
	//initiation of the game
	
	while(playerMoney > 0) {
		numRolls += 1;
		die1 = Math.floor(6*Math.random()) + 1;
		die2 = Math.floor(6*Math.random()) + 1;
		var sum = die1 + die2;
			
		if(sum == 7){
			playerMoney += 4;
		} else {
			playerMoney -= 2;
		}
		
		if(playerMoney > maxMoney){
			maxMoney = playerMoney;
			indexOfMaxMoney = numRolls;
		}	
	}
	//display results in table. we use the formatMoney() function to return the monetary amounts
	//in table in the correct money format
	
	document.getElementById("results").style.display = "block";
	document.getElementById("formInput").innerText = formatMoney(startingBet); //we include this to handle the case that the user initially eneterd an invalid starting bet
	document.getElementById("startingBetTable").innerText = formatMoney(startingBet);
	document.getElementById("totalRollsTable").innerText = numRolls;
	document.getElementById("maxMoneyTable").innerText = formatMoney(maxMoney);
	document.getElementById("indexOfMaxMoneyTable").innerText = indexOfMaxMoney;

	return false;
	
}

function formatMoney(num) {
	var useNum = 100 * num;
	var outNum = 0;
	
	if(useNum % 10 == 0){
		if(useNum % 100 == 0){
		outNum = String(useNum/100) + ".00";
		} else {
			outNum = String(useNum/100) + "0";
		}	
	} else {
		outNum = String(useNum/100);
	}
	
	return("$" + outNum);
}

function resetForm() {
	document.getElementById("results").style.display = "none";
	document.getElementById("startingBetInput").value = "$0.00";
}